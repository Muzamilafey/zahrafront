/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
*/
// This file has been repurposed to be the ResultDisplay component.
import React from 'react';
import {ClipboardCopyIcon, FileTextIcon, ReceiptIcon, ThumbsDownIcon, SaveIcon} from './icons';
import LoadingIndicator from './LoadingIndicator';
import { DocumentType } from '../types';

interface ResultDisplayProps {
  summary: string | null;
  invoice: string | null;
  isLoading: boolean;
  error: string | null;
  activeRequest: string | null;
  isSaved: boolean;
  onSave: (docType: DocumentType) => void;
}

const ResultDisplay: React.FC<ResultDisplayProps> = ({
  summary,
  invoice,
  isLoading,
  error,
  activeRequest,
  isSaved,
  onSave,
}) => {
  if (isLoading) {
    return <div className="h-full flex items-center justify-center"><LoadingIndicator activeRequest={activeRequest} /></div>;
  }
  if (error) {
    return (
      <div className="h-full flex items-center justify-center">
        <div className="text-center bg-red-900/20 border border-red-500 p-8 rounded-lg">
          <ThumbsDownIcon className="w-12 h-12 text-red-400 mx-auto mb-4" />
          <h2 className="text-2xl font-bold text-red-400 mb-4">Generation Failed</h2>
          <p className="text-red-300 text-sm">{error}</p>
        </div>
      </div>
    );
  }
  if (!summary && !invoice) {
    return (
      <div className="h-full flex items-center justify-center">
        <div className="text-center text-gray-600">
          <FileTextIcon className="w-24 h-24 mx-auto" />
          <p className="mt-4 text-xl">Generated documents will appear here</p>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {summary && (
        <ResultCard title="Discharge Summary" content={summary} icon={<FileTextIcon />} isSaved={isSaved} onSave={() => onSave('Summary')} />
      )}
      {invoice && (
        <ResultCard title="Invoice" content={invoice} icon={<ReceiptIcon />} isSaved={isSaved} onSave={() => onSave('Invoice')} />
      )}
    </div>
  );
};

// FIX: The `icon` prop should be of type `React.ReactElement` instead of `React.ReactNode`
// to ensure it can be cloned with `React.cloneElement` and new props can be added. This also removes the need for a type assertion.
const ResultCard: React.FC<{title: string; content: string; icon: React.ReactElement; isSaved: boolean; onSave: () => void;}> = ({ title, content, icon, isSaved, onSave }) => {
  const [copied, setCopied] = React.useState(false);

  const handleCopy = () => {
    navigator.clipboard.writeText(content);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };
  return (
    <div className="bg-gray-800/70 border border-gray-700 rounded-xl shadow-lg">
      <div className="p-4 flex justify-between items-center border-b border-gray-700">
        <div className="flex items-center gap-3">
          {React.cloneElement(icon, {className: 'w-6 h-6 text-cyan-400'})}
          <h3 className="text-xl font-semibold text-white">{title}</h3>
        </div>
        <div className="flex items-center gap-2">
            {!isSaved && (
                 <button
                 onClick={onSave}
                 className="flex items-center gap-2 px-3 py-1.5 text-sm bg-indigo-600 hover:bg-indigo-700 text-white rounded-md transition-colors"
               >
                 <SaveIcon className="w-4 h-4" />
                 Save
               </button>
            )}
            <button
            onClick={handleCopy}
            className="flex items-center gap-2 px-3 py-1.5 text-sm bg-gray-700 hover:bg-gray-600 rounded-md transition-colors"
            >
            <ClipboardCopyIcon className="w-4 h-4" />
            {copied ? 'Copied!' : 'Copy'}
            </button>
        </div>
      </div>
      <pre className="p-4 text-gray-300 text-sm whitespace-pre-wrap font-sans overflow-x-auto">
        {content}
      </pre>
    </div>
  );
}

export default ResultDisplay;
