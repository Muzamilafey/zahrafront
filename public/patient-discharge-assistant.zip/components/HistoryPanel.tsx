/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
*/
import React from 'react';
import { SavedDocument } from '../types';
import { FileTextIcon, ReceiptIcon, Trash2Icon, EyeIcon } from './icons';

interface HistoryPanelProps {
  documents: SavedDocument[];
  onView: (id: string) => void;
  onDelete: (id: string) => void;
  isLoading: boolean;
}

const HistoryPanel: React.FC<HistoryPanelProps> = ({ documents, onView, onDelete, isLoading }) => {
  return (
    <div className="mt-8">
      <h3 className="text-xl font-bold text-gray-200 mb-3">Saved History</h3>
      {documents.length === 0 ? (
        <p className="text-gray-500 text-sm text-center py-4">No saved documents yet.</p>
      ) : (
        <div className="max-h-60 overflow-y-auto space-y-2 pr-2">
          {documents.map((doc) => (
            <div key={doc.id} className="bg-gray-800 p-3 rounded-lg flex items-center justify-between">
              <div className="flex items-center gap-3 min-w-0">
                {doc.docType === 'Summary' ? 
                  <FileTextIcon className="w-5 h-5 text-blue-400 flex-shrink-0" /> :
                  <ReceiptIcon className="w-5 h-5 text-teal-400 flex-shrink-0" />
                }
                <div className="flex-grow min-w-0">
                  <p className="font-semibold text-white truncate">{doc.patientInfo.name || 'Unknown Patient'}</p>
                  <p className="text-xs text-gray-400">
                    {doc.docType} - {new Date(doc.timestamp).toLocaleDateString()}
                  </p>
                </div>
              </div>
              <div className="flex items-center gap-2 flex-shrink-0">
                <button
                  onClick={() => onView(doc.id)}
                  disabled={isLoading}
                  className="p-1.5 text-gray-400 hover:text-white disabled:text-gray-600 transition-colors"
                  aria-label="View document"
                >
                  <EyeIcon className="w-4 h-4" />
                </button>
                <button
                  onClick={() => onDelete(doc.id)}
                  disabled={isLoading}
                  className="p-1.5 text-gray-400 hover:text-red-500 disabled:text-gray-600 transition-colors"
                  aria-label="Delete document"
                >
                  <Trash2Icon className="w-4 h-4" />
                </button>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};

export default HistoryPanel;
