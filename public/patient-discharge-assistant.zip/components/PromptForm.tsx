/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
*/
// This file has been repurposed to be the PatientForm component.
import React, {useState, useRef, useEffect} from 'react';
import {DocumentType, PatientInfo} from '../types';
import {
  CalendarDaysIcon,
  FileTextIcon,
  PlusIcon,
  ReceiptIcon,
  UserIcon,
  XMarkIcon,
} from './icons';

interface PatientFormProps {
  onGenerate: (
    patientInfo: PatientInfo,
    clinicalNotes: string,
    docType: DocumentType,
  ) => void;
  isLoading: boolean;
  onClear: () => void;
}

const PatientForm: React.FC<PatientFormProps> = ({ onGenerate, isLoading, onClear }) => {
  const [patientInfo, setPatientInfo] = useState<PatientInfo>({
    name: '',
    id: '',
    admissionDate: '',
    dischargeDate: '',
    diagnosis: '',
  });
  const [clinicalNotes, setClinicalNotes] = useState('');
  const notesRef = useRef<HTMLTextAreaElement>(null);

  useEffect(() => {
    const textarea = notesRef.current;
    if (textarea) {
      textarea.style.height = 'auto';
      textarea.style.height = `${textarea.scrollHeight}px`;
    }
  }, [clinicalNotes]);

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const {name, value} = e.target;
    setPatientInfo((prev) => ({...prev, [name]: value}));
  };
  
  const handleClearForm = () => {
    setPatientInfo({ name: '', id: '', admissionDate: '', dischargeDate: '', diagnosis: '' });
    setClinicalNotes('');
    onClear();
  };


  const isFormEmpty = !Object.values(patientInfo).some(v => v) && !clinicalNotes;

  return (
    <div className="h-full flex flex-col">
      <div className="flex justify-between items-center mb-4">
        <h2 className="text-2xl font-bold text-gray-200">Patient Information</h2>
        <button
          onClick={handleClearForm}
          disabled={isFormEmpty || isLoading}
          className="flex items-center gap-1.5 text-sm text-gray-400 hover:text-white disabled:text-gray-600 disabled:cursor-not-allowed transition-colors"
        >
          <XMarkIcon className="w-4 h-4" /> Clear Form
        </button>
      </div>
      <form
        onSubmit={(e) => e.preventDefault()}
        className="space-y-4 flex-grow flex flex-col">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <InputField
            name="name"
            label="Patient Name"
            value={patientInfo.name}
            onChange={handleInputChange}
            icon={<UserIcon />}
            placeholder="e.g., John Doe"
          />
          <InputField
            name="id"
            label="Patient ID"
            value={patientInfo.id}
            onChange={handleInputChange}
            icon={<UserIcon />}
            placeholder="e.g., PID-12345"
          />
          <InputField
            name="admissionDate"
            label="Admission Date"
            type="date"
            value={patientInfo.admissionDate}
            onChange={handleInputChange}
            icon={<CalendarDaysIcon />}
          />
          <InputField
            name="dischargeDate"
            label="Discharge Date"
            type="date"
            value={patientInfo.dischargeDate}
            onChange={handleInputChange}
            icon={<CalendarDaysIcon />}
          />
        </div>
        <InputField
          name="diagnosis"
          label="Primary Diagnosis"
          value={patientInfo.diagnosis}
          onChange={handleInputChange}
          icon={<PlusIcon />}
          placeholder="e.g., Acute Myocardial Infarction"
        />
        <div className="flex-grow flex flex-col">
          <label className="text-sm block mb-1.5 font-medium text-gray-400">
            Clinical Notes & Instructions
          </label>
          <textarea
            ref={notesRef}
            value={clinicalNotes}
            onChange={(e) => setClinicalNotes(e.target.value)}
            placeholder="Enter details about the patient's stay, treatments, prescribed medications, lab results, and follow-up care..."
            className="flex-grow w-full bg-gray-800 border border-gray-600 rounded-lg p-3 appearance-none focus:ring-1 focus:ring-cyan-500 focus:border-cyan-500 resize-none"
            rows={8}
          />
        </div>

        <div className="flex flex-col sm:flex-row gap-3 pt-4">
          <button
            type="button"
            onClick={() => onGenerate(patientInfo, clinicalNotes, 'Summary')}
            disabled={isLoading || !clinicalNotes.trim()}
            className="w-full flex items-center justify-center gap-2 px-6 py-3 bg-blue-600 hover:bg-blue-700 text-white font-semibold rounded-lg transition-colors disabled:bg-gray-600 disabled:cursor-not-allowed">
            <FileTextIcon className="w-5 h-5" />
            Generate Summary
          </button>
          <button
            type="button"
            onClick={() => onGenerate(patientInfo, clinicalNotes, 'Invoice')}
            disabled={isLoading || !clinicalNotes.trim()}
            className="w-full flex items-center justify-center gap-2 px-6 py-3 bg-teal-600 hover:bg-teal-700 text-white font-semibold rounded-lg transition-colors disabled:bg-gray-600 disabled:cursor-not-allowed">
            <ReceiptIcon className="w-5 h-5" />
            Generate Invoice
          </button>
        </div>
      </form>
    </div>
  );
};

const InputField: React.FC<{
  name: string;
  label: string;
  value: string;
  onChange: (e: React.ChangeEvent<HTMLInputElement>) => void;
  // FIX: The `icon` prop should be of type `React.ReactElement` instead of `React.ReactNode`
  // to ensure it can be cloned with `React.cloneElement` and new props can be added. This also removes the need for a type assertion.
  icon: React.ReactElement;
  placeholder?: string;
  type?: string;
}> = ({name, label, value, onChange, icon, placeholder, type = 'text'}) => (
  <div>
    <label
      htmlFor={name}
      className="text-sm block mb-1.5 font-medium text-gray-400">
      {label}
    </label>
    <div className="relative">
      <div className="absolute inset-y-0 left-0 flex items-center pl-3 pointer-events-none text-gray-400">
        {React.cloneElement(icon, {className: 'w-5 h-5'})}
      </div>
      <input
        id={name}
        name={name}
        type={type}
        value={value}
        onChange={onChange}
        placeholder={placeholder}
        className="w-full bg-gray-800 border border-gray-600 rounded-lg pl-10 pr-3 py-2.5 appearance-none focus:ring-1 focus:ring-cyan-500 focus:border-cyan-500"
      />
    </div>
  </div>
);

export default PatientForm;
