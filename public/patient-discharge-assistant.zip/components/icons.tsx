/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
*/
import React from 'react';
// FIX: Add Key icon for ApiKeyDialog.
import {
  Stethoscope,
  User,
  CalendarDays,
  ClipboardCopy,
  FileText,
  Receipt,
  Plus,
  X,
  ThumbsDown,
  Key,
  Trash2,
  Eye,
  Save,
} from 'lucide-react';

const defaultProps = {
  strokeWidth: 1.5,
};

export const StethoscopeIcon: React.FC<React.SVGProps<SVGSVGElement>> = (
  props,
) => <Stethoscope {...defaultProps} {...props} />;

export const UserIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
  <User {...defaultProps} {...props} />
);

export const CalendarDaysIcon: React.FC<React.SVGProps<SVGSVGElement>> = (
  props,
) => <CalendarDays {...defaultProps} {...props} />;

export const ClipboardCopyIcon: React.FC<React.SVGProps<SVGSVGElement>> = (
  props,
) => <ClipboardCopy {...defaultProps} {...props} />;

export const FileTextIcon: React.FC<React.SVGProps<SVGSVGElement>> = (
  props,
) => <FileText {...defaultProps} {...props} />;

export const ReceiptIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
  <Receipt {...defaultProps} {...props} />
);

export const PlusIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
  <Plus {...defaultProps} {...props} />
);

export const XMarkIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
  <X {...defaultProps} {...props} />
);

export const ThumbsDownIcon: React.FC<React.SVGProps<SVGSVGElement>> = (
  props,
) => <ThumbsDown {...defaultProps} {...props} />;

// FIX: Export KeyIcon.
export const KeyIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
  <Key {...defaultProps} {...props} />
);

export const Trash2Icon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
    <Trash2 {...defaultProps} {...props} />
);

export const EyeIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
    <Eye {...defaultProps} {...props} />
);

export const SaveIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
  <Save {...defaultProps} {...props} />
);
