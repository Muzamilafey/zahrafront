/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
*/
import React, { useState, useEffect } from 'react';

const loadingMessages = [
  "Consulting with medical archives...",
  "Cross-referencing pharmaceuticals...",
  "Calculating billing codes...",
  "Formatting the documents...",
  "Checking the doctor's handwriting...",
  "Compiling final patient report...",
  "Ensuring HIPAA compliance...",
  "Polishing the paperwork...",
];

const LoadingIndicator: React.FC<{activeRequest: string | null}> = ({activeRequest}) => {
  const [messageIndex, setMessageIndex] = useState(0);

  useEffect(() => {
    const intervalId = setInterval(() => {
      setMessageIndex((prevIndex) => (prevIndex + 1) % loadingMessages.length);
    }, 2500); 

    return () => clearInterval(intervalId);
  }, []);

  return (
    <div className="flex flex-col items-center justify-center p-12 bg-gray-800/50 rounded-lg border border-gray-700">
      <div className="w-16 h-16 border-4 border-t-transparent border-cyan-500 rounded-full animate-spin"></div>
      <h2 className="text-2xl font-semibold mt-8 text-gray-200">Generating {activeRequest}...</h2>
      <p className="mt-2 text-gray-400 text-center transition-opacity duration-500">
        {loadingMessages[messageIndex]}
      </p>
    </div>
  );
};

export default LoadingIndicator;