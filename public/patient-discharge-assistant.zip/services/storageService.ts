/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
*/
import { SavedDocument, PatientInfo, DocumentType } from '../types';

const STORAGE_KEY = 'dischargeAssistantHistory';

export const getSavedDocuments = (): SavedDocument[] => {
  try {
    const savedData = localStorage.getItem(STORAGE_KEY);
    if (savedData) {
      const documents: SavedDocument[] = JSON.parse(savedData);
      // Sort by timestamp descending (newest first)
      return documents.sort((a, b) => b.timestamp - a.timestamp);
    }
  } catch (error) {
    console.error('Failed to retrieve or parse saved documents:', error);
  }
  return [];
};

export const saveDocument = (
  content: string,
  patientInfo: PatientInfo,
  docType: DocumentType
): SavedDocument => {
  const documents = getSavedDocuments();
  const newDocument: SavedDocument = {
    id: `doc_${Date.now()}`,
    timestamp: Date.now(),
    patientInfo,
    content,
    docType,
  };
  
  const updatedDocuments = [newDocument, ...documents];
  
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(updatedDocuments));
  } catch (error) {
    console.error('Failed to save document:', error);
    // Optionally, handle storage limit errors
  }
  
  return newDocument;
};

export const deleteDocument = (id: string): SavedDocument[] => {
  let documents = getSavedDocuments();
  const updatedDocuments = documents.filter((doc) => doc.id !== id);
  
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(updatedDocuments));
  } catch (error) {
    console.error('Failed to delete document:', error);
  }
  
  return updatedDocuments;
};
