/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
*/
import {GoogleGenAI} from '@google/genai';
import {DocumentType, PatientInfo} from '../types';

export const generateMedicalDocument = async (
  patientInfo: PatientInfo,
  clinicalNotes: string,
  docType: DocumentType,
): Promise<string> => {
  const ai = new GoogleGenAI({apiKey: process.env.API_KEY});

  let prompt = '';
  if (docType === 'Summary') {
    prompt = `You are a medical professional writing a patient discharge summary. Based on the following information, generate a comprehensive, well-structured, and professionally formatted summary. Ensure all key sections like Diagnosis, Hospital Course, Procedures, Discharge Medications, and Follow-up Instructions are included.

**Patient Information:**
- Name: ${patientInfo.name || 'N/A'}
- ID: ${patientInfo.id || 'N/A'}
- Admission Date: ${patientInfo.admissionDate || 'N/A'}
- Discharge Date: ${patientInfo.dischargeDate || 'N/A'}
- Primary Diagnosis: ${patientInfo.diagnosis || 'N/A'}

**Clinical Notes from Patient's Stay:**
${clinicalNotes}

Generate the discharge summary now.`;
  } else {
    // Invoice
    prompt = `You are a hospital billing administrator creating a patient invoice. Based on the following information and clinical notes, generate a detailed, itemized invoice. Research and include plausible, realistic costs (in USD) for any mentioned medications, lab tests, procedures, and other hospital services. Structure the invoice clearly with sections for each category (e.g., Room & Board, Pharmacy, Laboratory, Procedures) and a final total.

**Patient Information:**
- Name: ${patientInfo.name || 'N/A'}
- ID: ${patientInfo.id || 'N/A'}
- Billing Period: ${patientInfo.admissionDate || 'N/A'} to ${
      patientInfo.dischargeDate || 'N/A'
    }

**Clinical Notes for Billing Reference:**
${clinicalNotes}

Generate the itemized invoice now.`;
  }

  try {
    const response = await ai.models.generateContent({
      model: 'gemini-2.5-pro',
      contents: prompt,
    });
    return response.text;
  } catch (error) {
    console.error(`Error generating ${docType}:`, error);
    const errorMessage =
      error instanceof Error ? error.message : 'An unknown error occurred.';
    throw new Error(
      `Failed to generate ${docType}. Please try again. Details: ${errorMessage}`,
    );
  }
};
