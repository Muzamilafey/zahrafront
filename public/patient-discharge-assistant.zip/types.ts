/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
*/
export enum AppState {
  IDLE,
  LOADING,
  SUCCESS,
  ERROR,
}

export interface PatientInfo {
  name: string;
  id: string;
  admissionDate: string;
  dischargeDate: string;
  diagnosis: string;
}

export type DocumentType = 'Summary' | 'Invoice';

export interface SavedDocument {
    id: string;
    timestamp: number;
    patientInfo: PatientInfo;
    content: string;
    docType: DocumentType;
}
