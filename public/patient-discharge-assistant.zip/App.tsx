/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
*/
import React from 'react';
import PatientForm from './components/PromptForm';
import ResultDisplay from './components/VideoResult';
import HistoryPanel from './components/HistoryPanel';
import { generateMedicalDocument } from './services/geminiService';
import * as storage from './services/storageService';
import {
  AppState,
  DocumentType,
  PatientInfo,
  SavedDocument,
} from './types';
import { StethoscopeIcon } from './components/icons';

const App: React.FC = () => {
  const [appState, setAppState] = React.useState<AppState>(AppState.IDLE);
  
  // State for the currently displayed/generated result
  const [currentSummary, setCurrentSummary] = React.useState<string | null>(null);
  const [currentInvoice, setCurrentInvoice] = React.useState<string | null>(null);
  const [isCurrentResultSaved, setIsCurrentResultSaved] = React.useState<boolean>(false);
  const [lastPatientInfo, setLastPatientInfo] = React.useState<PatientInfo | null>(null);

  // State for saved document history
  const [savedDocuments, setSavedDocuments] = React.useState<SavedDocument[]>([]);
  
  const [errorMessage, setErrorMessage] = React.useState<string | null>(null);
  const [activeRequest, setActiveRequest] = React.useState<DocumentType | null>(null);

  React.useEffect(() => {
    // Load saved documents from storage on initial render
    setSavedDocuments(storage.getSavedDocuments());
  }, []);

  const handleGenerate = async (
    patientInfo: PatientInfo,
    clinicalNotes: string,
    docType: DocumentType,
  ) => {
    setAppState(AppState.LOADING);
    setErrorMessage(null);
    setCurrentSummary(null);
    setCurrentInvoice(null);
    setActiveRequest(docType);
    setLastPatientInfo(patientInfo);
    setIsCurrentResultSaved(false);

    try {
      const result = await generateMedicalDocument(
        patientInfo,
        clinicalNotes,
        docType,
      );
      if (docType === 'Summary') {
        setCurrentSummary(result);
      } else {
        setCurrentInvoice(result);
      }
      setAppState(AppState.SUCCESS);
    } catch (error) {
      const message =
        error instanceof Error ? error.message : 'An unknown error occurred.';
      setErrorMessage(message);
      setAppState(AppState.ERROR);
    } finally {
      setActiveRequest(null);
    }
  };

  const handleSave = (docType: DocumentType) => {
    if (!lastPatientInfo) return;
    const content = docType === 'Summary' ? currentSummary : currentInvoice;
    if (!content) return;

    storage.saveDocument(content, lastPatientInfo, docType);
    setIsCurrentResultSaved(true);
    // Refresh history list
    setSavedDocuments(storage.getSavedDocuments());
  };

  const handleView = (id: string) => {
    const doc = savedDocuments.find(d => d.id === id);
    if (!doc) return;
    
    setErrorMessage(null);
    setAppState(AppState.IDLE);
    setIsCurrentResultSaved(true);
    setLastPatientInfo(doc.patientInfo);

    if (doc.docType === 'Summary') {
      setCurrentSummary(doc.content);
      setCurrentInvoice(null);
    } else {
      setCurrentInvoice(doc.content);
      setCurrentSummary(null);
    }
  };

  const handleDelete = (id: string) => {
    const updatedDocs = storage.deleteDocument(id);
    setSavedDocuments(updatedDocs);
  };


  const handleClear = () => {
    setCurrentSummary(null);
    setCurrentInvoice(null);
    setErrorMessage(null);
    setAppState(AppState.IDLE);
    setLastPatientInfo(null);
    setIsCurrentResultSaved(false);
  };

  return (
    <div className="min-h-screen bg-gray-900 text-gray-200 flex flex-col font-sans">
      <header className="py-5 flex justify-center items-center px-8 border-b border-gray-700/50 bg-gray-900/80 backdrop-blur-sm sticky top-0 z-10">
        <div className="flex items-center gap-3">
          <StethoscopeIcon className="w-10 h-10 text-cyan-400" />
          <h1 className="text-4xl font-semibold tracking-wide text-center bg-gradient-to-r from-cyan-400 to-blue-500 bg-clip-text text-transparent">
            Patient Discharge Assistant
          </h1>
        </div>
      </header>
      <main className="w-full flex-grow grid grid-cols-1 lg:grid-cols-2 gap-8 p-8">
        <div className="lg:pr-4 lg:border-r lg:border-gray-700/50 flex flex-col">
           <PatientForm onGenerate={handleGenerate} isLoading={appState === AppState.LOADING} onClear={handleClear} />
           <HistoryPanel 
             documents={savedDocuments} 
             onView={handleView}
             onDelete={handleDelete}
             isLoading={appState === AppState.LOADING}
            />
        </div>
        <div className="lg:pl-4">
           <ResultDisplay
            summary={currentSummary}
            invoice={currentInvoice}
            isLoading={appState === AppState.LOADING}
            error={errorMessage}
            activeRequest={activeRequest}
            isSaved={isCurrentResultSaved}
            onSave={handleSave}
          />
        </div>
      </main>
    </div>
  );
};

export default App;
